# 小程序·云开发系列教程源码

## 注意事项
- 教程在：[小程序·云开发系列教程](https://github.com/TencentCloudBase/mp-book)
- 打开的时候记得填写 `project.config.json` 中的 `appid` 字段，其它功能的试用，请参考教程里的[小程序基础场景及开发教学](https://github.com/TencentCloudBase/mp-book/blob/master/basic-tutorial/readme.md) 进行配置试用。

## 图片预览

<p align="center">
    <img src="https://main.qcloudimg.com/raw/076879128bca9817c798568aa47759e8.png" width="1000px">
</p>

## 体验

<p align="center">
    <img src="https://ask.qcloudimg.com/draft/1011618/1rvk9ugc3n.png" width="500px">
</p>
