// 云函数入口文件
const cloud = require('wx-server-sdk')
const axios = require('axios')
const cheerio = require('cheerio')
const doubanbook = require('doubanbook')
cloud.init()

async function searchDouban(isbn){
  const url = 'https://search.douban.com/book/subject_search?search_text='+isbn

  let searchInfo = await axios.get(url)
  let reg = /window\.__DATA__ = "(.*)"/
  if (reg.test(searchInfo.data)){
    let searchData = doubanbook(RegExp.$1)[0]
    return searchData
  }
}

async function getDouban(isbn){
  const detailInfo = await searchDouban(isbn)
  const detailPage = await axios.get(detailInfo.url)
  const $ = cheerio.load(detailPage.data)
  let tags = []
  $('#db-tags-section a.tag').each((i,v)=>{
    tags.push({
      title: $(v).text()
    })
  })

  const ret = {
    tags,
    create_time:new Date().getTime(),
    image: detailInfo.cover_url,
    rate: detailInfo.rating.value,
    url: detailInfo.url,
    title: detailInfo.title,
    summary: $('#link-report .intro').text()
  }
  console.log(ret)
  return ret
}

getDouban('9787536692930 ')
// 云函数入口函数
exports.main = async (event, context) => {

  const {isbn} = event
  if(isbn){
    return getDouban(isbn)
  }else{
    return {
      code:-1,
      msg:'请扫描正确的图书'
    }
  }
}