import Vue from "./Vue.js"

export default Vue;