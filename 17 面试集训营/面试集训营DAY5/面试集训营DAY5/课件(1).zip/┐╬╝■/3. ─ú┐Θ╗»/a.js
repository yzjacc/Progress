var abc = 456;
//可能要使用b模块中的东西
var bmodule = require("./b")

console.log(bmodule)

module.exports = "asdfa";