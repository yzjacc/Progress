function getCharactors(){
    //返回一个充满各种字母和数字的数组
}


module.exports = {
    /**
     * 根据指定的长度产生一个随机的字符串
     * @param {*} length 
     */
    getRandomString: function (length) {

    },
    /**
     * 根据指定的最小值和最大值，产生一个随机整数
     * @param {*} min 
     * @param {*} max 
     */
    getRandomNumber: function (min, max) {

    }
}