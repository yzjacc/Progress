var abc = 123;

module.exports = "c.js";