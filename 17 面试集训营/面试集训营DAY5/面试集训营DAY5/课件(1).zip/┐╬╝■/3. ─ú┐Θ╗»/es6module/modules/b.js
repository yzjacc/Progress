var n = 0;

export default function(){
    console.log(n);
    n++;
}