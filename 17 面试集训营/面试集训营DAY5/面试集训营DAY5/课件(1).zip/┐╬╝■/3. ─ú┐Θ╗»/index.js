var c1 = require("./cache")

var c2 = require("./cache");

console.log(c1 === c2)