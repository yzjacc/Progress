// module.exports = {
//     a: 1,
//     b: 3,
//     c: function () {

//     },
//     d: function () {

//     },
//     //十几个属性
// }

exports.a = 1;


//

exports.b = 3;