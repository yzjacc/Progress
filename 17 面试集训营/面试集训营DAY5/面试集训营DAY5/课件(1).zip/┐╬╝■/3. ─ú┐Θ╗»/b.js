var abc = "789";

module.exports = {
    getRandomString: function (length) {

    },
    getRandomNumber: function (min, max) {
        
    }
}